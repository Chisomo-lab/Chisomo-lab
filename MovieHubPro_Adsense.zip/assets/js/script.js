function filterVideos() {
    const input = document.getElementById('searchInput');
    if(!input) return;
    const filter = input.value.toLowerCase();
    const cards = document.querySelectorAll('.movie-card');
    cards.forEach(card => {
        const title = card.querySelector('h3').textContent.toLowerCase();
        if(title.indexOf(filter) > -1){
            card.style.display = '';
        } else {
            card.style.display = 'none';
        }
    });
}

const cards = document.querySelectorAll('.movie-card');
cards.forEach(card => {
    card.addEventListener('mouseenter', () => card.style.transform = 'scale(1.03)');
    card.addEventListener('mouseleave', () => card.style.transform = 'scale(1)');
});